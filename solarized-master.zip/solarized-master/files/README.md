Solarized Package Downloads
===========================

If you are reviewing this on Github you probably just want to clone the project.

This project does double duty as the actual website (or rather subdirectory) 
for Solarized at <http://ethanschoonover.com/solarized/>. The current release 
downloads live here. I only build these for an actual release increment.

The version tagged and untagged files in this directory are identical.
